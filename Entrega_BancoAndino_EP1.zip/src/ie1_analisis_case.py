"""ie1_analisis_case.py – IE1"""
import re, json
def extract_requirements(text: str):
    problema = re.search(r'saturaci[oó]n.*?\.', text, re.IGNORECASE)
    return {
        "problema": problema.group(0) if problema else "No detectado",
        "requerimientos": [
            "Reducir 50% consultas",
            "Responder <1 min",
            "Mejorar NPS +20%"
        ],
        "restricciones": ["No exponer PII","Derivar a ejecutivo"]
    }
if __name__=="__main__":
    sample=open("src/caso_ejemplo.txt",encoding="utf-8").read()
    print(json.dumps(extract_requirements(sample),ensure_ascii=False,indent=2))
