# Referencias (APA)
CMF (2024). Normativa financiera. https://www.cmfchile.cl
Ipsos (2023). Informe satisfacción bancaria. Santiago: Ipsos Research.
LangChain (2024). RAG Documentation. https://python.langchain.com
