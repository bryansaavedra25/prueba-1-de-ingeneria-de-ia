"""ie2_prompts.py – IE2"""
BASE="Eres asistente del Banco Andino. Usa solo fuentes internas y normativa."
def credito(q): return f"{BASE}\nPregunta:{q}\nContexto:vencimiento créditos"
def apertura(q): return f"{BASE}\nPregunta:{q}\nContexto:apertura cuenta"
if __name__=="__main__": print(credito("¿Cuándo vence mi crédito?"))
