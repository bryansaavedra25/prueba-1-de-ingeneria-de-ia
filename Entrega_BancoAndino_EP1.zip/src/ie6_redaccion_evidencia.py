"""ie6_redaccion_evidencia.py – IE6"""
def validar(resp:str): return "fuente" in resp.lower() or "fuentes" in resp.lower()
if __name__=="__main__": print(validar("Respuesta simulada. Fuente: Manual"))
