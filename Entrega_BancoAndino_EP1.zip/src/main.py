"""main.py – Script principal"""
from ie1_analisis_case import extract_requirements
from ie3_pipeline_rag import SimpleRAG

def main():
    print("=== DEMO Banco Andino EP1 ===")
    texto = open("src/caso_ejemplo.txt", encoding="utf-8").read()
    analisis = extract_requirements(texto)
    print("\n--- IE1: Análisis ---")
    print(analisis)
    rag = SimpleRAG()
    rag.index_documents([
        {'id':'manual_producto','text':'Requisitos apertura cuenta: cédula, comprobante domicilio, formulario.'},
        {'id':'politicas_credito','text':'Los créditos vencen según calendario y se visualizan en la app.'}
    ])
    print("\n--- IE3: Consulta ---")
    print(rag.answer_query("¿Qué necesito para abrir una cuenta corriente?"))

if __name__ == "__main__":
    main()
