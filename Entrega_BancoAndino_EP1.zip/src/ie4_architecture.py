"""ie4_architecture.py – IE4"""
import json
diagram="[Cliente]->[API Gateway]->[RAG]->[LLM]->[Seguridad]->[Respuesta]"
components={"API Gateway":["Auth","Rate-limit"],"RAG":["Retriever","Reranker"],"LLM":["Modelo temp=0"],"Seguridad":["Filtro PII","Logs"]}
if __name__=="__main__":
    print(diagram)
    json.dump(components,open("src/architecture.json","w",encoding="utf-8"),ensure_ascii=False,indent=2)
