# Documentación Técnica (IE5–IE7)
- RAG integra normativa CMF y datos internos.
- VectorDB FAISS por rendimiento.
- Temperatura=0 en LLM.
- Seguridad: sin PII en bruto.
