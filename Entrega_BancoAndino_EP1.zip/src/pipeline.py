"""pipeline.py – Plantilla RAG simplificada"""
class RAGPipeline:
    def __init__(self):
        self.docs = []
    def index_documents(self, docs):
        self.docs.extend(docs)
    def answer_query(self, query):
        return "[SIMULADA] Respuesta basada en documentos internos y normativa CMF"
