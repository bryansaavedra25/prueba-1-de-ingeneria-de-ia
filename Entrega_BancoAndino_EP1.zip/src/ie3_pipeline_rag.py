"""ie3_pipeline_rag.py – IE3"""
class SimpleRAG:
    def __init__(self): self.docs=[]
    def index_documents(self,docs): self.docs.extend(docs)
    def retrieve(self,q): return [d for d in self.docs if any(w in d["text"].lower() for w in q.lower().split())]
    def answer_query(self,q):
        ctx=self.retrieve(q)
        fuentes=", ".join([d["id"] for d in ctx])
        return f"[SIMULADA] Respuesta. Fuentes:{fuentes}"
