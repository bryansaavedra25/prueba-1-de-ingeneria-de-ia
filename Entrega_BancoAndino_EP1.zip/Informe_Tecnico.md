# Informe Técnico – Evaluación Parcial N°1
**Asignatura:** Ingeniería de Soluciones con IA  
**Caso Organizacional:** Banco Andino  

## A. Análisis del caso organizacional (IE1)
El Banco Andino enfrenta saturación de canales de atención (call center y chat) con tiempos de espera >20 minutos.  
**Requerimientos:** reducir 50% consultas humanas, responder <1 minuto, mejorar NPS +20%.  
**Datos disponibles:** manuales de productos, políticas de crédito, guías de app, normativa CMF.  
**Restricciones:** no exponer PII, derivar a ejecutivo cuando aplique.  

## B. Formulación de prompts (IE2)
Prompts diseñados con rol, fuentes y fallback a ejecutivo. Ejemplos: vencimiento de crédito y apertura de cuenta.  

## C. Pipeline RAG (IE3–IE4)
Consulta → preprocesamiento → retrieval interno/externo → reranking → LLM → seguridad → respuesta.  

## D. Arquitectura (IE5–IE6)
Componentes: Interfaz, API Gateway, Orquestador RAG, VectorDB, Document Store, LLM, Seguridad.  
Ver src/architecture.txt e ie4_architecture.py.  

## E. Documentación técnica (IE7–IE8)
Decisiones: RAG+LLM, FAISS, temperatura=0, seguridad y trazabilidad.  

## F. Redacción técnica (IE9)
Informe coherente, técnico, respaldado con evidencias.  

## G. Referencias (APA)
- CMF (2024). Normativa financiera en Chile. https://www.cmfchile.cl  
- Ipsos (2023). Informe satisfacción bancaria en Chile. Santiago: Ipsos Research.  
- LangChain (2024). Documentation RAG. https://python.langchain.com  
