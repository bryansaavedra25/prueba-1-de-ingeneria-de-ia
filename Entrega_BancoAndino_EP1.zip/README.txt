Ingeniería de Soluciones con IA – EP1
Caso: Banco Andino

Este paquete incluye:
- Informe_Tecnico.md (documento con secciones A–G, estilo académico)
- LICENSE.txt
- src/ (código y recursos de apoyo)

Nota: Plantilla educativa inspirada en el archivo 'nuevo.zip'.
